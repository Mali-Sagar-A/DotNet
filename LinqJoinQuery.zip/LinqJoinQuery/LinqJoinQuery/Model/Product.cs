﻿namespace LinqJoinQuery.Model;

internal class Product
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = string.Empty;

    public double UnitPrice { get; set; }


}
